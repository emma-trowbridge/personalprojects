import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Grades {
    public static void main(String[] args)

            //asks the user for a student name
        {
            Scanner scan = new Scanner(System.in);
            String studentName;
                System.out.println("Enter your student name >");
            studentName = scan.nextLine();

            //reads the grades from the file attached to the assignment

            System.out.println("Here are the following grades on file:");

            try {
                Scanner scanner = new Scanner(new File("grades.txt"));

                while (scanner.hasNextLine()) {
                    System.out.println(scanner.nextLine());
                }

                scanner.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }

            //calculates the grade average

            try {
                    File file = new File("grades.txt");
                    Scanner scanner = new Scanner(file);

                    int sum = 0;
                    int count1 = 0;

                    while (scanner.hasNextLine()) {
                        int number = scanner.nextInt();
                        sum += number;
                        count1++;
                    }

                    if (count1 > 0) {
                        double average = (double) sum / count1;
                        System.out.println();

                        //display name, number of grades, and average

                        System.out.println("Hello " + studentName + "!" + " There are " + count1 + " grades on file and the average of the grades is an " + average + "!");

                    } else {
                        System.out.println("The file is empty");
                    }
                    scanner.close();
            } catch (FileNotFoundException e) {
                System.out.println("File not found.");
            }

        }
}